class Subject:
    def __init__(self, properties):
        self.properties = properties

    def create(self):
        pass
